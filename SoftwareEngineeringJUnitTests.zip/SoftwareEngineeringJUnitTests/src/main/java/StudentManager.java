import java.util.ArrayList;
import java.util.List;

public class StudentManager {
    private List<Student> students = new ArrayList<>();

    public void addStudent(Student student) {
        students.add(student);
    }

    public void deleteStudent(int studentID) {
        students.removeIf(student -> student.getStudentID() == studentID);
    }

    public void editStudent(int studentID, String name, String email, String courseID, int courseYear) {
        for (Student student : students) {
            if (student.getStudentID() == studentID) {
                student.setStudentName(name);
                student.setStudentEmail(email);
                student.setCourseID(courseID);
                student.setCourseYear(courseYear);
                return;
            }
        }
    }

    public List<Student> getStudentList() {
        return students;
    }
}
