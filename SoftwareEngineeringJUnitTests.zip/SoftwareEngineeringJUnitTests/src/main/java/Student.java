public class Student {

    private int studentID;
    private String studentName;
    private String studentEmail;
    private String courseID;
    private int courseYear;

    public Student(int studentID, String studentName, String studentEmail, String courseID, int year) {
        this.studentID = studentID;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.courseID = courseID;
        this.courseYear = courseYear;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public int getCourseYear() {
        return courseYear;
    }

    public void setCourseYear(int year) {
        this.courseYear = year;
    }

    @Override
    public String toString() {
        return
                "Student ID: " + studentID + "\n" +
                        "Student Name: " + studentName + "\n" +
                        "Student Email: " + studentEmail + "\n" +
                        "Course ID: " + courseID + "\n" +
                        "Course Year: " + courseYear;
    }
}
