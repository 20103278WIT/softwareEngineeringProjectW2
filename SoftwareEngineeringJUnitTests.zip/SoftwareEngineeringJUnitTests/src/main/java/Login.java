public class Login {
    private int studentID;
    private String studentEmail;
    private String loginPassword;

    public Login(int studentID, String studentEmail, String loginPassword) {
        this.studentID = studentID;
        this.studentEmail = studentEmail;
        this.loginPassword = loginPassword;
    }

    public boolean authenticate(String email, String password) {
        return this.studentEmail.equals(email) && this.loginPassword.equals(password);
    }
}