public class Application {
    private String courseID;
    private int courseYear;
    private String moduleName;
    private String lecturerName;

    public Application(String courseID, int courseYear, String moduleName, String lecturerName) {
        this.courseID = courseID;
        this.courseYear = courseYear;
        this.moduleName = moduleName;
        this.lecturerName = lecturerName;
    }

    public String getCourseID() {
        return courseID;
    }

    public int getCourseYear() {
        return courseYear;
    }

    public String getModuleName() {
        return moduleName;
    }

    public String getLecturerName() {
        return lecturerName;
    }

    public void displayInfo() {
        System.out.println("Course: " + courseID + " (Year " + courseYear + ")");
        System.out.println("Module: " + moduleName);
        System.out.println("Lecturer: " + lecturerName);
    }
}