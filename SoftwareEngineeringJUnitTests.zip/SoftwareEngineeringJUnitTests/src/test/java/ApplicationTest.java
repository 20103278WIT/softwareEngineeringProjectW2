import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


class ApplicationTest {
    private Application application;

    // setup new application test before each test
    @BeforeEach
    void setUp() {
        application = new Application("SE600", 2, "Software Engineering Practice", "Trish O'Neill");
    }

    @Test
    void testGetCourseID() {
        assertEquals("SE600", application.getCourseID());
    }

    @Test
    void testGetCourseYear() {
        assertEquals(2, application.getCourseYear());
    }

    @Test
    void testGetModuleName() {
        assertEquals("Software Engineering Practice", application.getModuleName());
    }

    @Test
    void testGetLecturerName() {
        assertEquals("Trish O'Neill", application.getLecturerName());
    }
}
