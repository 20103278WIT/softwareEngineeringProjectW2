import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StudentTest {
    private StudentManager studentManager;

    // setup each student before testing
    @BeforeEach
    void setUp() {
        studentManager = new StudentManager();
        studentManager.addStudent(new Student(20103278, "Thomas O’Mahony", "20103278@wit.ie", "SE600", 1));
        studentManager.addStudent(new Student(20106558, "Agnieszka Krzemkowska", "20106558@setu.ie", "SE600", 2));
        studentManager.addStudent(new Student(20107772, "Rian McHale", "20107772@mail.wit.ie", "SE602", 3));
    }

    // adds a student to see if list size increases
    @Test
    void testAddStudent() {
        studentManager.addStudent(new Student(20108888, "John Doe", "20108888@wit.ie", "SE601", 1));
        assertEquals(4, studentManager.getStudentList().size());
    }

    // deletes a student to see if list size decreases
    @Test
    void testDeleteStudent() {
        studentManager.deleteStudent(20103278);
        assertEquals(2, studentManager.getStudentList().size());
    }

    // check if edited student still exists
    @Test
    void testEditStudentNotNull() {
        studentManager.editStudent(20106558, "Agnieszka K.", "20106558@setu.ie", "SE601", 3);
        Student student = studentManager.getStudentList().stream()
                .filter(s -> s.getStudentID() == 20106558)
                .findFirst()
                .orElse(null);
        assertNotNull(student);
    }

    // check if edited student name was edited
    @Test
    void testEditStudentNameChanged() {
        studentManager.editStudent(20106558, "Agnieszka K.", "20106558@setu.ie", "SE601", 3);
        Student student = studentManager.getStudentList().stream()
                .filter(s -> s.getStudentID() == 20106558)
                .findFirst()
                .orElse(null);
        if (student != null) {
            assertEquals("Agnieszka K.", student.getStudentName());
        }
    }
}

