import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LoginTest {
    private Login login;

    // setup a new login object
    @BeforeEach
    void setUp() {
        login = new Login(101, "20107772@mail.wit.ie", "ilovesoftwareengineering");
    }

    // tests if credentials are correct
    @Test
    void testAuthenticateSuccess() {
        assertTrue(login.authenticate("20107772@mail.wit.ie", "ilovesoftwareengineering"));
    }

    @Test
    void testAuthenticateFailure() {
        assertFalse(login.authenticate("20107772@mail.wit.ie", "wrongpassword"));
    }
}